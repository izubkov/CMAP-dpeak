library(testthat)
library(cmapR)

test_check("cmapR")