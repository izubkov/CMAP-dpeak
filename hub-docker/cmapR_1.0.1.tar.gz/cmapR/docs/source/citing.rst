.. _citing:

Citation Information
====================

If you use GCTx and/or cmapR in your work, please cite `Enache et al.`_

.. _Enache et al.: https://www.biorxiv.org/content/early/2017/11/30/227041
